const AWS = require('aws-sdk');

// Configure DynamoDB DocumentClient for AWS
const dynamoDB = new AWS.DynamoDB.DocumentClient({
    region: process.env.AWS_REGION || 'us-east-1',
    maxRetries: 3,
    retryDelayOptions: { base: 300 }
});

// Configure API Gateway Management API for WebSocket responses
const apiGateway = new AWS.ApiGatewayManagementApi({
    endpoint: process.env.WEBSOCKET_API_URL 
      ? process.env.WEBSOCKET_API_URL.replace("wss://", "").replace("/Dev", "")
      : "82hp8bmge8.execute-api.us-east-1.amazonaws.com"
});

const validateInput = (body) => {
    if (!body || typeof body !== 'object') {
        throw new Error('Invalid request body');
    }
    if (body.action !== 'getCurrentState') {
        throw new Error('Invalid action');
    }
    if (!body.data || !body.data.userId) {
        throw new Error('Missing userId');
    }
};

exports.handler = async (event) => {
    const connectionId = event.requestContext.connectionId;
    
    try {
        console.log('Event:', JSON.stringify(event, null, 2));
        
        // Parse the WebSocket message body
        let body;
        try {
            body = JSON.parse(event.body);
        } catch (error) {
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({ 
                    action: 'error',
                    data: { error: 'Invalid JSON in request body' }
                })
            }).promise();
            return { statusCode: 200 };
        }

        try {
            validateInput(body);
        } catch (error) {
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({ 
                    action: 'error',
                    data: { error: error.message }
                })
            }).promise();
            return { statusCode: 200 };
        }

        const { userId } = body.data;

        // Get user metadata from DynamoDB
        const params = {
            TableName: process.env.USER_METADATA_TABLE,
            Key: { PK: `USER#${userId}` }  // Fixed: Add USER# prefix
        };

        let userMetadata;
        try {
            console.log('Querying DynamoDB with params:', params);
            userMetadata = await dynamoDB.get(params).promise();
            console.log('DynamoDB response:', userMetadata);
            
            if (!userMetadata.Item) {
                console.log('User not found, creating default response');
                // Send default/empty state for new user
                await apiGateway.postToConnection({
                    ConnectionId: connectionId,
                    Data: JSON.stringify({
                        action: 'currentState',
                        data: {
                            userId: userId,
                            connectionId: connectionId,
                            chatId: null,
                            ready: false,
                            questionIndex: 0,
                            lastSeen: new Date().toISOString(),
                            createdAt: new Date().toISOString()
                        }
                    })
                }).promise();
                return { statusCode: 200 };
            }
        } catch (error) {
            console.error('Error getting user metadata:', error);
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({ 
                    action: 'error',
                    data: { error: 'Error retrieving user metadata' }
                })
            }).promise();
            return { statusCode: 200 };
        }

        const item = userMetadata.Item;
        
        // Send the current state back to the client
        const response = {
            action: 'currentState',
            data: {
                userId: item.PK.replace('USER#', ''),
                connectionId: item.connectionId || connectionId,
                chatId: item.chatId || null,
                ready: item.ready || false,
                questionIndex: item.questionIndex || 0,
                lastSeen: item.lastSeen || new Date().toISOString(),
                createdAt: item.createdAt || new Date().toISOString()
            }
        };
        
        console.log('Sending response:', response);
        
        await apiGateway.postToConnection({
            ConnectionId: connectionId,
            Data: JSON.stringify(response)
        }).promise();
        
        return { statusCode: 200 };
        
    } catch (error) {
        console.error('Error in getCurrentState:', error);
        try {
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({ 
                    action: 'error',
                    data: { error: 'Internal server error' }
                })
            }).promise();
        } catch (sendError) {
            console.error('Error sending error response:', sendError);
        }
        return { statusCode: 200 };
    }
};
