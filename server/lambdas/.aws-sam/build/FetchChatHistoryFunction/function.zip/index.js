const AWS = require('aws-sdk');

// Configure DynamoDB client for AWS
const dynamoDB = new AWS.DynamoDB.DocumentClient({
    region: process.env.AWS_REGION || 'us-east-1'
});

// Configure API Gateway Management API for WebSocket responses
const apiGateway = new AWS.ApiGatewayManagementApi({
    endpoint: process.env.WEBSOCKET_API_URL 
      ? process.env.WEBSOCKET_API_URL.replace("wss://", "").replace("/Dev", "")
      : "82hp8bmge8.execute-api.us-east-1.amazonaws.com"
});

exports.handler = async (event, context) => {
    const connectionId = event.requestContext.connectionId;
    
    try {
        console.log('Event:', JSON.stringify(event, null, 2));
        
        // Parse the WebSocket message body
        let body;
        try {
            body = JSON.parse(event.body);
        } catch (error) {
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'error',
                    data: { error: 'Invalid JSON in request body' }
                })
            }).promise();
            return { statusCode: 200 };
        }

        // Extract parameters from the action/data structure
        const data = body.data || {};
        const { chatId, limit = 20, lastEvaluatedKey } = data;

        if (!chatId) {
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'error',
                    data: { error: 'Missing chatId parameter' }
                })
            }).promise();
            return { statusCode: 200 };
        }

        // Query messages for the chat
        const params = {
            TableName: process.env.MESSAGES_TABLE,
            KeyConditionExpression: 'PK = :chatId',
            ExpressionAttributeValues: {
                ':chatId': `CHAT#${chatId}`
            },
            ScanIndexForward: false, // false = descending order (newest first)
            Limit: limit
        };

        // Add ExclusiveStartKey if provided
        if (lastEvaluatedKey) {
            try {
                params.ExclusiveStartKey = JSON.parse(decodeURIComponent(lastEvaluatedKey));
            } catch (error) {
                console.log('Invalid lastEvaluatedKey, ignoring:', error);
            }
        }

        console.log('Querying messages with params:', params);
        const result = await dynamoDB.query(params).promise();
        console.log('DynamoDB query result:', result);
        
        // Send the chat history back to the client
        const response = {
            action: 'chatHistory',
            data: {
                messages: result.Items || [],
                lastEvaluatedKey: result.LastEvaluatedKey 
                    ? encodeURIComponent(JSON.stringify(result.LastEvaluatedKey))
                    : null,
                hasMore: !!result.LastEvaluatedKey
            }
        };
        
        console.log('Sending chat history response:', response);
        
        await apiGateway.postToConnection({
            ConnectionId: connectionId,
            Data: JSON.stringify(response)
        }).promise();
        
        return { statusCode: 200 };
        
    } catch (error) {
        console.error('Error:', error);
        try {
            await apiGateway.postToConnection({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'error',
                    data: { error: 'Internal server error', details: error.message }
                })
            }).promise();
        } catch (sendError) {
            console.error('Error sending error response:', sendError);
        }
        return { statusCode: 200 };
    }
}; 