const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { ApiGatewayManagementApiClient, PostToConnectionCommand } = require('@aws-sdk/client-apigatewaymanagementapi');

// Configure DynamoDB client for AWS SDK v3
const ddbClient = new DynamoDBClient({
    region: process.env.AWS_REGION || 'us-east-1'
});
const dynamoDB = DynamoDBDocumentClient.from(ddbClient);

// Configure API Gateway Management API for WebSocket responses
const getApiGatewayManagementApi = (event) => {
    const domain = event.requestContext.domainName;
    const stage = event.requestContext.stage;
    const endpoint = `https://${domain}/${stage}`;
    
    return new ApiGatewayManagementApiClient({
        endpoint: endpoint,
        region: process.env.AWS_REGION || 'us-east-1'
    });
};

exports.handler = async (event) => {
    const connectionId = event.requestContext.connectionId;
    const apiGateway = getApiGatewayManagementApi(event);
    
    try {
        console.log('Event:', JSON.stringify(event, null, 2));
        
        const body = JSON.parse(event.body);
        const { chatId } = body.data;

        if (!chatId) {
            console.log('Missing chatId in request');
            const command = new PostToConnectionCommand({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'error',
                    data: { error: 'Missing chatId' }
                })
            });
            await apiGateway.send(command);
            return { statusCode: 200 };
        }

        // Check if CONVERSATIONS_TABLE environment variable exists
        const conversationsTable = process.env.CONVERSATIONS_TABLE;
        if (!conversationsTable) {
            console.error('CONVERSATIONS_TABLE environment variable not set');
            const command = new PostToConnectionCommand({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'error',
                    data: { error: 'Configuration error: CONVERSATIONS_TABLE not set' }
                })
            });
            await apiGateway.send(command);
            return { statusCode: 200 };
        }

        // Get conversation metadata
        console.log('Querying conversation for chatId:', chatId, 'in table:', conversationsTable);
        
        // Try different key formats - start with the most likely
        const keyFormats = [
            { PK: `CHAT#${chatId}` },
            { chatId: chatId },
            { id: chatId },
            { PK: chatId, SK: 'METADATA' }
        ];
        
        let conversation = null;
        let usedKeyFormat = null;
        
        for (const keyFormat of keyFormats) {
            try {
                console.log('Trying key format:', keyFormat);
                const command = new GetCommand({
                    TableName: conversationsTable,
                    Key: keyFormat
                });
                const result = await dynamoDB.send(command);
                
                if (result.Item) {
                    conversation = result;
                    usedKeyFormat = keyFormat;
                    console.log('Found conversation with key format:', keyFormat);
                    break;
                }
            } catch (error) {
                console.log('Failed with key format:', keyFormat, 'Error:', error.message);
                continue;
            }
        }

        console.log('Conversation query result:', conversation);

        if (!conversation || !conversation.Item) {
            console.log('Conversation not found, sending empty metadata');
            // Send empty conversation metadata instead of error
            const command = new PostToConnectionCommand({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'conversationSync',
                    data: {
                        chatId: null,
                        participants: [],
                        lastMessage: null,
                        lastUpdated: null,
                        endedBy: null,
                        endReason: null,
                        createdAt: null
                    }
                })
            });
            await apiGateway.send(command);
            return { statusCode: 200 };
        }

        // Extract conversation data based on the key format that worked
        const item = conversation.Item;
        const extractedChatId = item.chatId || 
                                (item.PK && item.PK.startsWith('CHAT#') ? item.PK.replace('CHAT#', '') : null) ||
                                item.id ||
                                chatId;

        // Send conversation metadata to the requesting user
        const response = {
            action: 'conversationSync',
            data: {
                chatId: extractedChatId,
                participants: item.participants || [],
                lastMessage: item.lastMessage || null,
                lastUpdated: item.lastUpdated || item.updatedAt || null,
                endedBy: item.endedBy || null,
                endReason: item.endReason || null,
                createdAt: item.createdAt || item.timestamp || null
            }
        };
        
        console.log('Sending conversation sync response:', response);
        
        const command = new PostToConnectionCommand({
            ConnectionId: connectionId,
            Data: JSON.stringify(response)
        });
        await apiGateway.send(command);

        return { statusCode: 200 };

    } catch (error) {
        console.error('Error syncing conversation:', error);
        console.error('Error stack:', error.stack);
        
        try {
            const command = new PostToConnectionCommand({
                ConnectionId: connectionId,
                Data: JSON.stringify({
                    action: 'error',
                    data: { 
                        error: 'Internal server error', 
                        details: error.message,
                        chatId: event.body ? JSON.parse(event.body).data?.chatId : null
                    }
                })
            });
            await apiGateway.send(command);
        } catch (sendError) {
            console.error('Error sending error response:', sendError);
        }
        return { statusCode: 200 };
    }
}; 